package com.teama8se.moviebookingbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieBookingBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
