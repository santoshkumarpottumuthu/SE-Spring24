package com.teama8se.moviebookingbackend.repository;


import com.teama8se.moviebookingbackend.entities.Ticket;
import com.teama8se.moviebookingbackend.enums.TicketType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Integer> {

    List<Ticket> findByBookingId(int bookingId);

    List<Ticket> findBySeatId(String seatId);

    List<Ticket> findByTicketType(TicketType ticketType);

}
