package com.teama8se.moviebookingbackend.constants;

/**
 * @author Santosh created on 24-03-2024 02:19
 **/
public class EmailConstants {

    public static final String emailBodyForSuspended = "Dear Customer, \n"
            + "We regret to inform you that your account has been temporarily suspended due to violation of terms and services.\n"
            + "\n"
            + "If you believe that this suspension is some error, please reach out to us at moviesaticu@gmail.com\n"
            + "\n"
            + "Regards"
            + "Team ICU Movies";

    public static final String emailBodyForReActivatedAccount = "Dear Customer, \n"
            + "We are delighted to inform you that your account has been re-activated. You can now enjoy the features and services provided by us.\n"
            + "\n"
            + "If you still run into any issues, please reach out to us at moviesaticu@gmail.com\n"
            + "\n"
            + "Regards"
            + "Team ICU Movies";
}
