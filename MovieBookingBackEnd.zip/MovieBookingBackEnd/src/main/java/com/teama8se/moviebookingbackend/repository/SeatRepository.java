package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Seat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.relational.core.sql.In;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Santosh created on 27-04-2024 17:32
 **/

@Repository
public interface SeatRepository extends JpaRepository<Seat, Integer> {

    List<Seat> findBySeatNumber(String seatNumber);

    List<Seat> findByIsReserved(boolean isReserved);

}
