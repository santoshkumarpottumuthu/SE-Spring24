package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author Santosh created on 24-03-2024 00:43
 **/
public interface AdminRepository extends JpaRepository<Admin, Integer> {

    List<Admin> findAll();

    Admin findByEmailAndPassword(String email, String password);

    List<Admin> findByEmail(String email);

    Admin findByUserID(int userId);

}
