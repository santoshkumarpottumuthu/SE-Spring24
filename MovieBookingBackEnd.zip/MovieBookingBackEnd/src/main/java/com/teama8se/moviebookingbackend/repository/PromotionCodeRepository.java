package com.teama8se.moviebookingbackend.repository;
import com.teama8se.moviebookingbackend.entities.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Santosh created on 24-03-2024 02:51
 **/

@Repository
public interface PromotionCodeRepository extends JpaRepository<Promotion,Integer> {

    List<Promotion> findByPromoId(int promoId);

    List<Promotion> findByPromoCode(String promocode);

//    @Query(nativeQuery = true, value = "update promotion set status = false where promo_id = :promoId")
//    void updatePromotionByPromoId(@Param("promoId") int promoId, boolean status);

}
