package com.teama8se.moviebookingbackend.designpatterns.facade;

import com.teama8se.moviebookingbackend.entities.BookingRequest;
import com.teama8se.moviebookingbackend.entities.ShowReservations;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

public interface BookingFacade {

    Map<Integer, String> reserveSeat(ShowReservations request);
    BookingRequest addBooking(BookingRequest bookingRequest);
    List<BookingRequest> getCustomerBookings(Map<String, Integer> request);

}
