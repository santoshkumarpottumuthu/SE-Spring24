package com.teama8se.moviebookingbackend.designpatterns.facade;

import com.teama8se.moviebookingbackend.entities.Admin;
import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.Movie;
import com.teama8se.moviebookingbackend.entities.Promotion;
import org.springframework.http.ResponseEntity;

import java.util.Map;

/**
 * @author Santosh created on 12-04-2024 23:47
 **/
public interface AdminFacade {

    Map<Integer, Movie> addMovie(Movie movie);
    Map<Integer, Movie> updateMovie(Movie movie);
    boolean deleteMovie(Movie movie);
    ResponseEntity<Admin> addAdmin(Admin admin);
    ResponseEntity<Admin> updateAdmin(Admin admin);
    boolean deleteAdmin(Admin admin);
    void addPromotion(Promotion promo);

    void deletePromotion(Promotion promo);
    void updateCustomer(Customer customer);

    void deleteCustomer(Customer customer);

}
