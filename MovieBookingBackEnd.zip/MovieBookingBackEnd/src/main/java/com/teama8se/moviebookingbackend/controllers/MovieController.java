package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.entities.Movie;
import com.teama8se.moviebookingbackend.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 24-03-2024 00:26
 **/


@RestController
@CrossOrigin(origins = "*")
public class MovieController {

    @Autowired
    private MovieRepository movieDao;

    @PostMapping("/addmovie")
    public Map<Integer, Movie> addMovie(@RequestBody Movie movie) {
            ResponseEntity.ok(movieDao.save(movie));
        Map<Integer, Movie> map = new HashMap<Integer, Movie>();
        map.put(200, movie);
        return map;
    }

    @GetMapping("/getallmovies")
    public List<Movie> getinfo() {
        List<Movie> list = movieDao.findAll();
        return list;
    }

    @PostMapping("/getmoviedetails")
    public ResponseEntity<Movie> getMovieDetailByTitle(@RequestBody Movie movie) {

        String moviename = movie.getMovieTitle();
        List<Movie> movieList = movieDao.findByMovieTitle(moviename);

        if (movieList.isEmpty()) {
            return new ResponseEntity<Movie>(HttpStatus.NO_CONTENT);
        }

        Movie movieResponse = movieList.get(0);
        return new ResponseEntity<Movie>(movieResponse,
                HttpStatus.OK);

    }

    @PostMapping("/updatemovie")
    public Map<Integer, Movie> editmovie(@RequestBody Movie movie) {
        ResponseEntity.ok(movieDao.save(movie));
        Map<Integer, Movie> map = new HashMap<Integer, Movie>();
        map.put(400, movie);
        return map;
    }

    @DeleteMapping("/deletemovie")

    public boolean deleteMovie(@RequestBody Movie movie) {
        movieDao.delete(movie);
        return true;
    }

    public Movie getMovieById(int id) {
        return movieDao.findById(id).get();
    }
}

