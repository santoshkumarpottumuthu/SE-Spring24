package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.Customer;

import java.util.List;

public interface UserService {

    List<Customer> getAllUsers();
    List<Customer> fetchUserByUserID(int userID);
    List<Customer> findByEmailAndPassword(String email, String password);
    List<Customer> findByEmail(String email);
    List<Customer> findBypromotionsSubscribed(boolean promotionsSubscribed);

    boolean checkIfCustomerExists(String email);

    Customer save(Customer customer);

    void delete(Customer customer);
}
