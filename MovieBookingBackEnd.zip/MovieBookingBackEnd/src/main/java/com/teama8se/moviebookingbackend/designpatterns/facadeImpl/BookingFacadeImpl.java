package com.teama8se.moviebookingbackend.designpatterns.facadeImpl;

import com.teama8se.moviebookingbackend.designpatterns.decorator.AdultTicketDecorator;
import com.teama8se.moviebookingbackend.designpatterns.decorator.BaseTicketDecorator;
import com.teama8se.moviebookingbackend.designpatterns.decorator.ChildTicketDecorator;
import com.teama8se.moviebookingbackend.designpatterns.facade.BookingFacade;
import com.teama8se.moviebookingbackend.entities.*;
import com.teama8se.moviebookingbackend.enums.BookingStatus;
import com.teama8se.moviebookingbackend.enums.PaymentStatus;
import com.teama8se.moviebookingbackend.enums.TicketType;
import com.teama8se.moviebookingbackend.repository.BookingRepository;
import com.teama8se.moviebookingbackend.service.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 27-04-2024 15:07
 **/
@Service
@Slf4j
public class BookingFacadeImpl implements BookingFacade {

    private BookingRepository bookingRepository;
    private ShowReservationService showReservationService;
    private PromotionService promotionService;
    private BookingService bookingService;
    private TicketService ticketService;
    private CustomerService customerService;
    private ShowService showService;

    private MovieService movieService;
    private EmailSenderService emailSenderService;

    public BookingFacadeImpl(BookingRepository bookingRepository, ShowReservationService showReservationService, PromotionService promotionService, BookingService bookingService, TicketService ticketService, CustomerService customerService, ShowService showService, MovieService movieService, EmailSenderService emailSenderService) {
        this.bookingRepository = bookingRepository;
        this.showReservationService = showReservationService;
        this.promotionService = promotionService;
        this.bookingService = bookingService;
        this.ticketService = ticketService;
        this.customerService = customerService;
        this.showService = showService;
        this.movieService = movieService;
        this.emailSenderService = emailSenderService;
    }

    @Override
    public Map<Integer, String> reserveSeat(ShowReservations request) {
        return null;
    }

    @Override
    public BookingRequest addBooking(BookingRequest bookingRequest) {
        Booking savedBooking = bookingRepository.save(bookingRequest.getBooking());
        BaseTicketDecorator ticketDecor = new BaseTicketDecorator();
        int bookingPrice = 0;
        for (Ticket ticket : bookingRequest.getTickets()) {
            bookingPrice += bookTicket(ticket, bookingRequest, savedBooking, ticketDecor);
        }
        //Applying promocode
        String code = bookingRequest.getBooking().getPromoCode();
        log.info("Price before applying promo code : {}",bookingPrice);
        bookingPrice = applyPromoCode(code, bookingPrice, ticketDecor);
        log.info("Price after applying promo code : {}",bookingPrice);
        bookingRequest.getBooking().setTotalPrice(bookingPrice);
        bookingRequest.getBooking().setBookingStatus(BookingStatus.CONFIRMED);
        bookingRequest.getBooking().setPaymentStatus(PaymentStatus.SUCCESS);
        bookingService.addBooking(bookingRequest.getBooking());

        Customer customer = new Customer();
        PaymentCards cards = new PaymentCards();
        Show show = new Show();
        Movie movie = new Movie();

        customer.setUserID(bookingRequest.getBooking().getCustomerId());
        cards.setCardID(bookingRequest.getBooking().getPaymentId());
        cards.setUserID(bookingRequest.getBooking().getCustomerId());
        customer = customerService.getCustomerById(customer).getBody().getCustomer();
        cards = customerService.getCardById(cards).getBody();
        show = showService.getShowByShowID(bookingRequest.getBooking().getShowId());
        movie = movieService.getMovieById(bookingRequest.getBooking().getMovieId());

        bookingRequest.setMovie(movie);
        bookingRequest.setShow(show);
        sendBookingConfirmationEmail(bookingRequest.getBooking(), bookingRequest.getTickets(), customer, cards, show, movie);
        return bookingRequest;
    }

    private int applyPromoCode(String code, int bookingPrice, BaseTicketDecorator ticketDecor) {
        if (!code.isEmpty()) {
            double discount = promotionService.getDiscountByCode(code);
            double percentage = (bookingPrice * discount) / 100;
            bookingPrice -= percentage;
        }
        bookingPrice += ticketDecor.getSalesTax() + ticketDecor.getOnlineFee();
        return bookingPrice;
    }

    private double bookTicket(Ticket ticket, BookingRequest bookingRequest, Booking savedBooking, BaseTicketDecorator ticketDecor) {
        double bookingPrice = 0;

        showReservationService.reserveSeat(
                new ShowReservations(
                        ticket.getSeatId(),
                        bookingRequest.getBooking().getShowId()));
        ticket.setBookingId(savedBooking.getBookingId());

        if (ticket.getTicketType().equals(TicketType.ADULT)) {
            ticketDecor = new AdultTicketDecorator();
        } else {
            ticketDecor = new ChildTicketDecorator();
        }
        double price = ticketDecor.calculateTicketPrice();
        bookingPrice += price;
        ticket.setTicketPrice(price);
        ticketService.addTicket(ticket);
        return bookingPrice;
    }

    @Override
    public List<BookingRequest> getCustomerBookings(Map<String, Integer> request) {

        int customerID = request.get("customerID");
        List<Booking> bookings = bookingService.findByCustomerId(customerID);
        List<BookingRequest> bookingRequests = new ArrayList<BookingRequest>();

        for(Booking booking : bookings) {

            List<Ticket> ticketsList = ticketService.getTickets(booking.getBookingId());
            BookingRequest bookingRequest = new BookingRequest();
            bookingRequest.setBooking(booking);
            bookingRequest.setTickets(ticketsList.toArray(new Ticket[0]));
            bookingRequest.setMovie(movieService.getMovieById(bookingRequest.getBooking().getMovieId()));
            bookingRequest.setShow(showService.getShowByShowID(bookingRequest.getBooking().getShowId()));
            bookingRequests.add(bookingRequest);
        }
        return bookingRequests;
    }

    public void sendBookingConfirmationEmail(Booking booking, Ticket[] tickets, Customer customer, PaymentCards cards, Show show, Movie movie) {

        String emailSubject = "Booking Confirmation";
        String emailBody = "Dear " + customer.getFirstName() + ",\n"
                + "\nThank you for your order. Here are your booking confirmation details:\n"
                + "Booking Details:\n"
                + "Booking ID: " + booking.getBookingId()
                + "\nBooking Date: " + booking.getBookingDate()
                + "\nBooking Status: " + booking.getBookingStatus()
                + "\n\nShow Details:\n"
                + "Show Timings: " + show.getShowDate() + " " + show.getShowTime().getTime() + ":00\n"
                + "Movie Title:  " + movie.getMovieTitle()
                + "\nShow Duration: " + show.getDuration_minutes()
                + "\n\nTicket Details: ";

        int i = 1;
        for (Ticket ticket : tickets) {
            emailBody += "\nTicket Number: " + i
                    + "\nSeat Number: " + ticket.getSeatId()
                    + "\nTicket Type: " + ticket.getTicketType()
                    + "\nTicket Price: " + ticket.getTicketPrice() + "\n";

        }

        if (!booking.getPromoCode().isEmpty()) {
            emailBody += "\nPromo applied: " + booking.getPromoCode() + "\n";
        }
        emailBody += "\nYour total order price is " + booking.getTotalPrice()
                + " paid with card ending " + cards.getCardNumber().substring(cards.getCardNumber().length() - 4) + "\n";

        emailBody += "\nThank you for choosing our service. We look forward to serve you again \n"
                + "\nRegards\n"
                + "Team PopcornPicks";

        emailSenderService.sendEmail(customer.getEmail(), emailBody, emailSubject);
    }

}
