package com.teama8se.moviebookingbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieBookingBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieBookingBackEndApplication.class, args);
	}

}
