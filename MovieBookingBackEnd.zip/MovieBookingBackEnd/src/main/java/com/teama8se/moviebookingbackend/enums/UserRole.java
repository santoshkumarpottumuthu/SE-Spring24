package com.teama8se.moviebookingbackend.enums;

public enum UserRole {
	ADMIN,
	CUSTOMER
}
