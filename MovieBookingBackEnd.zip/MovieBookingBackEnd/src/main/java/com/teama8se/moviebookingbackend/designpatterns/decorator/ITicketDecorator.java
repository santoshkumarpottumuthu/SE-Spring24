package com.teama8se.moviebookingbackend.designpatterns.decorator;

public interface ITicketDecorator {

    double calculateTicketPrice();
}
