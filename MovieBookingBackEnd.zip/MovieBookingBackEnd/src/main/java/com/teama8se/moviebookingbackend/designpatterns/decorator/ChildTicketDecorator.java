package com.teama8se.moviebookingbackend.designpatterns.decorator;

/**
 * @author Santosh created on 14-04-2024 21:22
 **/
public class ChildTicketDecorator extends BaseTicketDecorator{

    private double childTicketPrice;

    public ChildTicketDecorator() {
        super();
        this.childTicketPrice = 10;
    }

    @Override
    public double calculateTicketPrice() {
        return super.calculateTicketPrice();
    }

    public double getChildTicketPrice() {
        return childTicketPrice;
    }
}
