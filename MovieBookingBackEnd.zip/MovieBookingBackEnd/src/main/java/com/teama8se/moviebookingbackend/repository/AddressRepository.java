package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Address;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Santosh created on 28-03-2024 22:36
 **/
public interface AddressRepository extends JpaRepository<Address,Integer> {
}
