package com.teama8se.moviebookingbackend.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teama8se.moviebookingbackend.enums.CustomerStatus;
import com.teama8se.moviebookingbackend.enums.UserRole;
import jakarta.persistence.*;
import lombok.Getter;

import java.io.Serializable;

@Getter
@Entity
@Table(name="customer")
public class Customer implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int userID;
	@JsonProperty("email")
	private String email;
	private String password;
	@Enumerated(EnumType.ORDINAL)
	private UserRole userRole;
	private String firstName;
	private String lastName;
	@Column(length = 15)
	private String phoneNumber;
	private String street;
	private String city;
	private String state;
	private int zipcode;
	@Enumerated(EnumType.ORDINAL)
	private CustomerStatus customerStatusID;
	private int verificationCode;
	private boolean promotionsSubscribed;
//	private boolean isFirstLogin;

	public Customer() {
	}

	public Customer(int userID, String email, String password, UserRole userRole, String firstName, String lastName,
			String phoneNumber, CustomerStatus customerStatusID, int verificationCode, boolean promotionsSubscribed,  String street, String city, String state, int zipcode) {
		super();
		this.userID = userID;
		this.email = email;
		this.password = password;
		this.userRole = userRole;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.customerStatusID = customerStatusID;
		this.verificationCode = verificationCode;
		this.promotionsSubscribed = promotionsSubscribed;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setCustomerStatusID(CustomerStatus customerStatusID) {
		this.customerStatusID = customerStatusID;
	}

	public void setVerificationCode(int verificationCode) {
		this.verificationCode = verificationCode;
	}

	public void setPromotionsSubscribed(boolean promotionsSubscribed) {
		this.promotionsSubscribed = promotionsSubscribed;
	}

//	public boolean isFirstLogin() {
//		return isFirstLogin;
//	}
//
//	public void setFirstLogin(boolean firstLogin) {
//		isFirstLogin = firstLogin;
//	}


	
	
}
