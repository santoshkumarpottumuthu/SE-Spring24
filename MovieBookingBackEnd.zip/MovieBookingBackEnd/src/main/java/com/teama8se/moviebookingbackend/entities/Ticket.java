package com.teama8se.moviebookingbackend.entities;

import com.teama8se.moviebookingbackend.enums.TicketType;
import jakarta.persistence.*;

@Entity
@Table(name="ticket")
public class Ticket {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int ticketId;
	private int bookingId;
	private String seatId;
	@Enumerated(EnumType.ORDINAL)
	private TicketType ticketType;
	private double ticketPrice;
	
	
	
	public Ticket() {
		super();
	}



	public Ticket(int ticketId, int bookingId, String seatId, TicketType ticketType, double ticketPrice) {
		super();
		this.ticketId = ticketId;
		this.bookingId = bookingId;
		this.seatId = seatId;
		this.ticketType = ticketType;
		this.ticketPrice = ticketPrice;
	}


	public int getTicketId() {
		return ticketId;
	}



	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}



	public int getBookingId() {
		return bookingId;
	}



	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getSeatId() {
		return seatId;
	}


	public void setSeatId(String seatId) {
		this.seatId = seatId;
	}



	public TicketType getTicketType() {
		return ticketType;
	}



	public void setTicketType(TicketType ticketType) {
		this.ticketType = ticketType;
	}



	public double getTicketPrice() {
		return ticketPrice;
	}



	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	
	
}
