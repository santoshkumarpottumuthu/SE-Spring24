package com.teama8se.moviebookingbackend.service.impl;

import com.teama8se.moviebookingbackend.entities.Admin;
import com.teama8se.moviebookingbackend.repository.AdminRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 24-03-2024 00:50
 **/
@Service
public class AdminService {

    private final AdminRepository adminRepository;

    AdminService(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    public Admin registerOrUpdateAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    public List<Admin> getAllUsers() {
        return adminRepository.findAll();
    }

    public Admin findByEmailAndPassword(String email, String password) {
        return adminRepository.findByEmailAndPassword(email, password);
    }

    public List<Admin> findByEmail(String email) {
        return adminRepository.findByEmail(email);
    }

    public Admin findByUserId(int userId) {
        return adminRepository.findByUserID(userId);
    }

    public List<Admin> getAllAdmins(){
        return adminRepository.findAll();
    }

    public void deleteAdmin(Admin admin){
        adminRepository.delete(admin);
    }
}
