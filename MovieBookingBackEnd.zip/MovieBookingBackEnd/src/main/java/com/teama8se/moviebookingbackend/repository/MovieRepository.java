package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Movie;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MovieRepository extends JpaRepository<Movie,Integer> {

    List<Movie> findAll();

    //Override the findByField method with different return type
    List<Movie> findByMovieTitle(String movieTitle);
}
