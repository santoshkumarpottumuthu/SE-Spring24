package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.constants.EmailConstants;
import com.teama8se.moviebookingbackend.enums.CustomerStatus;
import com.teama8se.moviebookingbackend.entities.Admin;
import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.PaymentCards;
import com.teama8se.moviebookingbackend.service.CustomerService;
import com.teama8se.moviebookingbackend.service.EmailSenderService;
import com.teama8se.moviebookingbackend.service.PaymentCardsService;
import com.teama8se.moviebookingbackend.service.UserService;
import com.teama8se.moviebookingbackend.service.impl.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author Santosh created on 24-03-2024 00:26
 **/

@RestController
@CrossOrigin("*")
public class AdminController {

    private final AdminService adminService;
    private final UserService userService;
    private final EmailSenderService emailSenderService;
    private final PaymentCardsService paymentCardsService;

    private final CustomerService customerService;

    @Autowired
    public AdminController(AdminService adminService, UserService userService, EmailSenderService emailSenderService, PaymentCardsService paymentCardsService, CustomerService customerService) {
        this.adminService = adminService;
        this.userService = userService;
        this.emailSenderService = emailSenderService;
        this.paymentCardsService = paymentCardsService;
        this.customerService = customerService;
    }

    @PostMapping("/registerAdmin")
    public ResponseEntity<Admin> register(@RequestBody Admin admin) {
        if (!checkAdminExists(admin)) {
            return new ResponseEntity<Admin>(admin, HttpStatus.BAD_REQUEST);
        }
        ResponseEntity.ok(adminService.registerOrUpdateAdmin(admin));
        return new ResponseEntity<Admin>(admin, HttpStatus.OK);
    }


    @PostMapping("/updateAdmin")
    public ResponseEntity<Admin> update(@RequestBody Admin admin) {
        if (!checkAdminExists(admin)) {
            return new ResponseEntity<Admin>(admin, HttpStatus.NO_CONTENT);
        }
        ResponseEntity.ok(adminService.registerOrUpdateAdmin(admin));
        return new ResponseEntity<Admin>(admin, HttpStatus.OK);
    }


    @GetMapping("/getAllAdmins")
    public List<Admin> getAllCustomers() {
        List<Admin> list = adminService.getAllAdmins();
        list.stream().forEach(e -> e.setPassword(""));
        return list;
    }


    //This method will return false only if there is an admin with same email
    public boolean checkAdminExists(Admin admin) {
        String email = admin.getEmail();
        List<Admin> adminList = adminService.findByEmail(email);
        return adminList.isEmpty();
    }

    @PostMapping("/getAdmin")
    public ResponseEntity<Admin> getAdmin(@RequestBody Admin admin) {

        String email = admin.getEmail();
        String password = admin.getPassword();

        if (checkAdminExists(admin)) {
            return new ResponseEntity<Admin>(HttpStatus.NO_CONTENT);
        }

        Admin existingAdmin = adminService.findByEmailAndPassword(email, password);

        if (Objects.isNull(existingAdmin)) {
            System.out.println("Incorrect Password");
            return new ResponseEntity<Admin>(HttpStatus.NON_AUTHORITATIVE_INFORMATION);
        }

        return new ResponseEntity<Admin>(existingAdmin,
                HttpStatus.OK);

    }

    @PostMapping("/deleteAdmin")
    public boolean deleteAdmin(@RequestBody Admin admin) {
        adminService.deleteAdmin(admin);
        return true;
    }


    @PostMapping("/suspendCustomer")
    public Map<Integer, Customer> suspendCustomer(@RequestBody Customer customer) {
        customer = customerService.suspendCustomer(customer);
        Map<Integer, Customer> map = new HashMap<Integer, Customer>();
        map.put(400, customer);
        return map;
    }

    @PostMapping("/activateCustomer")
    public Map<Integer, Customer> activateCustomer(@RequestBody Customer customer) {
        customer = customerService.activateCustomer(customer);
        Map<Integer, Customer> map = new HashMap<Integer, Customer>();
        map.put(400, customer);
        return map;
    }


    @PostMapping("/deleteCustomer")
    public boolean deleteCustomer(@RequestBody Customer customer) {
        return customerService.deleteUser(customer);
    }


}
