package com.teama8se.moviebookingbackend.enums;

public enum BookingStatus {
	
	CONFIRMED,
	PENDING,
	CANCELLED

}
