package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.ShowReservations;
import com.teama8se.moviebookingbackend.repository.ShowBookingRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 12-04-2024 23:23
 **/
@Service
public class ShowReservationService {

    private final ShowBookingRepository showBookingRepository;

    public ShowReservationService(ShowBookingRepository showBookingRepository) {
        this.showBookingRepository = showBookingRepository;
    }

    public List<ShowReservations> fetchShowBookingsByShowId(int showId) {
        return showBookingRepository.findByShowID(showId);
    }

    public Map<Integer, List<String>> getReservedSeats(@RequestBody Map<String, Integer> request) {

        Map<Integer, List<String>> map = new HashMap<Integer, List<String>>();
        List<ShowReservations> reservations = showBookingRepository.findByShowID(request.get("showID"));

        List<String> reservedSeats = new ArrayList<String>();
        for (ShowReservations reservation : reservations) {
            reservedSeats.add(reservation.getSeatNumber());
        }

        map.put(400, reservedSeats);
        return map;

    }

    public Map<Integer, String> reserveSeat(ShowReservations request) {

        Map<Integer, String> result = new HashMap<Integer, String>();
        String[] seats = request.seatNumber.split(",");
        for (int i = 0; i < seats.length; i++) {
            ShowReservations reservation = new ShowReservations(seats[i], request.getShowID());
            showBookingRepository.save(reservation);
        }
        result.put(400, "Successful");
        return result;

    }

    public void save(ShowReservations reservation) {
        showBookingRepository.save(reservation);
    }
}
