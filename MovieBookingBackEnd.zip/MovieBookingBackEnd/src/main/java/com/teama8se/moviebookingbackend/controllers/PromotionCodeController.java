package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.Promotion;
import com.teama8se.moviebookingbackend.repository.PromotionCodeRepository;
import com.teama8se.moviebookingbackend.service.EmailSenderService;
import com.teama8se.moviebookingbackend.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Santosh created on 24-03-2024 00:27
 **/

@RestController
@CrossOrigin("*")
@Slf4j
public class PromotionCodeController {

    @Autowired
    private PromotionCodeRepository promotionDao;

    @Autowired
    private CustomerController customerController;

    @Autowired
    private EmailSenderService emailSenderService;

    @Autowired
    private UserService userService;

    //add promotion
    @PostMapping("/addPromo")
    public Map<Integer, Promotion> addPromo(@RequestBody Promotion promo) {

        Map<Integer, Promotion> result = new HashMap<Integer, Promotion>();
        if (!checkPromoExists(promo)) {
            promo.setStatus(true);
            ResponseEntity.ok(promotionDao.save(promo));
            List<Customer> list = getSubscribedCustomers();
            for (Customer cust : list) {
                String emailSubject = "Exciting News: Exclusive Promotion Inside!";
                emailSenderService.sendEmail(cust.getEmail(), promo.toString(), emailSubject);
            }
            result.put(200, promo);
            return result;
        }
        log.info("PromoCode already exists in the system");
        result.put(208, promo);
        return result;
    }

    //get all the promo codes
    @GetMapping("/getAllPromos")
    public List<Promotion> getAllPromotions() {
        List<Promotion> list = promotionDao.findAll();
//        List<Promotion> activePromoCodes = list.stream().filter(e -> e.isStatus()).collect(Collectors.toList());
        return list;
    }


    //update promotion
    @PostMapping("/updatePromo")
    public ResponseEntity<Promotion> updatePromo(@RequestBody Promotion promo) {


        if (checkPromoExists(promo)) {
            ResponseEntity.ok(promotionDao.save(promo));
            return new ResponseEntity<Promotion>(promo, HttpStatus.OK);
        }
        return new ResponseEntity<Promotion>(promo, HttpStatus.BAD_REQUEST);
    }


    //delete promotion
    @PostMapping("/deletePromo")
    public boolean deleteMovie(@RequestBody Promotion promo) {
//        promotionDao.updatePromotionByPromoId(promo.getPromoId(),false);
        promotionDao.delete(promo);
        return true;
    }

    @PostMapping("/getPromoByCode")
    public ResponseEntity<Promotion> getPromoByCode(@RequestBody Promotion promo) {


        String promoCode = promo.getPromoCode();
        List<Promotion> promoList = promotionDao.findByPromoCode(promoCode);

        if (!checkPromoExists(promo)) {
            return new ResponseEntity<Promotion>(HttpStatus.NO_CONTENT);
        }

        Promotion promoResponse = promoList.get(0);
        return new ResponseEntity<Promotion>(promoResponse,
                HttpStatus.OK);

    }

    public boolean checkPromoExists(Promotion promo) {

        String promoCode = promo.getPromoCode();
        List<Promotion> promoList = promotionDao.findByPromoCode(promoCode);
        log.info("Promo List Size : {}",promoList.size());
        if (promoList.isEmpty()) {
            System.out.println("No promo code found");
            return false;
        }

        return true;

    }

    public double getDiscountByCode(String code) {

        List<Promotion> promoList = promotionDao.findByPromoCode(code);
        return promoList.get(0).getDiscountApplied();

    }


    public List<Customer> getSubscribedCustomers() {
        List<Customer> list = userService.findBypromotionsSubscribed(true);
        return list;
    }


}

