package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.entities.Ticket;
import com.teama8se.moviebookingbackend.service.TicketService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 12-04-2024 23:03
 **/

@RestController
@CrossOrigin("*")
public class TicketController {

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    public Map<Integer, Ticket> addTicket(Ticket ticket) {

        Map<Integer, Ticket> result = new HashMap<Integer, Ticket>();
        ResponseEntity.ok(ticketService.save(ticket));
        result.put(400, ticket);
        return result;

    }

    public List<Ticket> getTickets(int bookingID) {
        return ticketService.findByBookingId(bookingID);
    }


}
