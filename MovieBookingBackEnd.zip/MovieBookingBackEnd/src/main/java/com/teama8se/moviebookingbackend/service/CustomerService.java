package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.constants.EmailConstants;
import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.CustomerBody;
import com.teama8se.moviebookingbackend.entities.PaymentCards;
import com.teama8se.moviebookingbackend.enums.CustomerStatus;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 24-03-2024 01:38
 **/

@Service
public class CustomerService {

    private final UserService userService;
    private final EmailSenderService emailSenderService;
    private final PaymentCardsService paymentCardsService;
    private final TextEncryptor textEncryptor;


    public CustomerService(UserService userService, EmailSenderService emailSenderService, PaymentCardsService paymentCardsService, TextEncryptor textEncryptor) {
        this.userService = userService;
        this.emailSenderService = emailSenderService;
        this.paymentCardsService = paymentCardsService;
        this.textEncryptor = textEncryptor;
    }


    public Customer suspendCustomer(Customer customer) {
        customer=userService.fetchUserByUserID(customer.getUserID()).get(0);
        customer.setCustomerStatusID(CustomerStatus.INACTIVE);
        String emailSubject = "Notice of Account Suspension";
        emailSenderService.sendEmail(customer.getEmail(), EmailConstants.emailBodyForSuspended, emailSubject);
        return userService.save(customer);
    }


    public Customer activateCustomer(Customer customer) {
        customer=userService.fetchUserByUserID(customer.getUserID()).get(0);
        customer.setCustomerStatusID(CustomerStatus.ACTIVE);
        String emailSubject = "Notice of Account Re-Activation";

        emailSenderService.sendEmail(customer.getEmail(), EmailConstants.emailBodyForReActivatedAccount, emailSubject);
        return userService.save(customer);
    }

    public boolean deleteUser(Customer customer) {
        userService.fetchUserByUserID(customer.getUserID()).get(0);
        List<PaymentCards> cards = paymentCardsService.getCardsByUserId(customer.getUserID());
        for (PaymentCards card : cards) {
            paymentCardsService.deleteCard(card);
        }
        userService.delete(customer);
        return true;
    }

    public ResponseEntity<CustomerBody> getCustomerById(Customer customer) {
        int id = customer.getUserID();

        List<Customer> customerList = userService.fetchUserByUserID(id);
        if (customerList.isEmpty()) {
            return new ResponseEntity<CustomerBody>(HttpStatus.NO_CONTENT);
        }        //Decrypt the password in response
        Customer customerResponse = customerList.get(0);
        try {
            customerResponse.setPassword(textEncryptor.decrypt(customerResponse.getPassword()));
        } catch (Exception e) {
            // TODO Auto-generated catch block

        }
        CustomerBody result = new CustomerBody();
        result.setCustomer(customerResponse);
        // Fetch the cards and attach to the response
        List<PaymentCards> cards = paymentCardsService.getCardsByUserId(customerResponse.getUserID());

        for (PaymentCards card : cards) {
            paymentCardsService.decryptCard(card);
        }

        result.setCardDetails(cards);

        return new ResponseEntity<>(result,
                HttpStatus.OK);
    }

    public ResponseEntity<PaymentCards> getCardById(PaymentCards card) {
        List<PaymentCards> cardList = paymentCardsService.getCardsByUserId(card.getUserID());
        if (cardList.isEmpty()) {
            return new ResponseEntity<PaymentCards>(HttpStatus.NO_CONTENT);
        }
        PaymentCards cardResponse = paymentCardsService.decryptCard(cardList.get(0));
        return new ResponseEntity<PaymentCards>(cardResponse,
                HttpStatus.OK);
    }
}
