package com.teama8se.moviebookingbackend.designpatterns.decorator;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Santosh created on 14-04-2024 21:17
 **/

@Getter
@Setter
public class BaseTicketDecorator implements ITicketDecorator {

    protected double salesTax;
    protected double onlineFee;
    protected ITicketDecorator ticketDecorator;

    @Override
    public double calculateTicketPrice() {
        return 0;
    }
}
