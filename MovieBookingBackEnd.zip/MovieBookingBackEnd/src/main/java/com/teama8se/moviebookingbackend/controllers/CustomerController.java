package com.teama8se.moviebookingbackend.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.teama8se.moviebookingbackend.enums.CustomerStatus;
import com.teama8se.moviebookingbackend.entities.CustomBody;
import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.CustomerBody;
import com.teama8se.moviebookingbackend.entities.PaymentCards;
import com.teama8se.moviebookingbackend.service.CustomerService;
import com.teama8se.moviebookingbackend.service.EmailSenderService;
import com.teama8se.moviebookingbackend.service.PaymentCardsService;
import com.teama8se.moviebookingbackend.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 24-03-2024 00:26
 **/

@RestController
@CrossOrigin("*")
@Slf4j
public class CustomerController {

    private final UserService userService;
    private final EmailSenderService emailSenderService;
    private final TextEncryptor textEncryptor;
    private final PaymentCardsService paymentCardsService;
    private final CustomerService customerService;

    private final int max = 99999;
    private final int min = 10000;

    @Autowired
    public CustomerController(UserService userService, EmailSenderService emailSenderService, TextEncryptor textEncryptor, PaymentCardsService paymentCardsService, CustomerService customerService) {
        this.userService = userService;
        this.emailSenderService = emailSenderService;
        this.textEncryptor = textEncryptor;
        this.paymentCardsService = paymentCardsService;
        this.customerService = customerService;
    }


    @PostMapping("/registerCustomer")
    public Map<Integer, Customer> register(@RequestBody CustomBody customerBody) {

        Map<Integer, Customer> result = new HashMap<Integer, Customer>();
        Customer customer = customerBody.getCustomer();

        if (userService.checkIfCustomerExists(customer.getEmail())) {
            result.put(208, customer);
            return result;
        }

        //Sending verification code
        int code = (int) Math.floor(Math.random() * (max - min + 1) + min);
        customer.setVerificationCode(code);
        String emailBody = "Please use this verification code to activate your account: " + code;
        String emailSubject = "Verify Account";
        try {
            emailSenderService.sendEmail(customer.getEmail(), emailBody, emailSubject);

        } catch (Exception e) {
            log.error("Exception occured : {}", e.getStackTrace());
            result.put(502, customer);
            return result;
        }

        //Encrypting the password to store in the database
        try {
            customer.setPassword(textEncryptor.encrypt(customer.getPassword()));
            customer.setCustomerStatusID(CustomerStatus.INACTIVE);
        } catch (Exception e) {
            log.error("Exception occured : {}", e.getStackTrace());
        }
        ResponseEntity.ok(userService.save(customer));

        //Saving encrypted card details
        PaymentCards card = customerBody.getCardDetails();
        if (!card.getCardNumber().isEmpty()) {
            card.setUserID(customer.getUserID());
            paymentCardsService.save(paymentCardsService.encryptCard(card));
        }


        //Decrypt the password in response
        try {
            customer.setPassword(textEncryptor.decrypt(customer.getPassword()));
        } catch (Exception e) {
            log.error("Exception occured : {}", e.getStackTrace());
        }

        result.put(200, customer);
        return result;


    }


    @PostMapping("/verifyCustomer")
    public Map<Integer, Customer> verifyCustomer(@RequestBody String json) throws JsonProcessingException {
        log.info("Received info : {}",json);
        ObjectMapper mapper = new ObjectMapper();
        Customer customer = mapper.readValue(json, Customer.class);
        Map<Integer, Customer> result = new HashMap<Integer, Customer>();
        //Find the customer by email
        List<Customer> list = userService.findByEmail(customer.getEmail());

        if (customer.getVerificationCode() == list.get(0).getVerificationCode()) {

            //Set the customer status as active after verifying
            customer.setCustomerStatusID(CustomerStatus.ACTIVE);
            try {
                customer.setPassword(textEncryptor.encrypt(customer.getPassword()));
            } catch (Exception e) {
                log.error("Exception occured : {}", e.getStackTrace());
            }
            ResponseEntity.ok(userService.save(customer));

            //Decrypt the password in the response
            try {
                customer.setPassword(textEncryptor.decrypt(customer.getPassword()));
            } catch (Exception e) {
                // TODO Auto-generated catch block
                log.error("Exception occured : {}", e.getStackTrace());
            }
            result.put(200, customer);
            return result;
        }
        result.put(400, customer);
        return result;

    }

    @PostMapping("/updateCustomer")
    public ResponseEntity<Customer> update(@RequestBody Customer customer) {

        //Check if customer exists or not
        if (!userService.checkIfCustomerExists(customer.getEmail())) {
            return new ResponseEntity<Customer>(HttpStatus.NO_CONTENT);
        }

        //Send the profile update email
        String emailBody = "Your profile has been updated successfully!!";
        String emailSubject = "Dear User, we have updated profile as per your request.\n \n \n Regards, \n Team ICU";
        try {
            emailSenderService.sendEmail(customer.getEmail(), emailBody, emailSubject);

        } catch (Exception e) {
            log.error("Exception occured : {}", e.getStackTrace());
            return new ResponseEntity<Customer>(HttpStatus.BAD_REQUEST);

        }

        //Encrypt the password and update the details
        try {
            customer.setPassword(textEncryptor.encrypt(customer.getPassword()));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            log.error("Exception occured : {}", e.getStackTrace());
        }
        ResponseEntity.ok(userService.save(customer));


//		//Update encrypted card details
//		for(PaymentCards card: customerBody.getCardDetails()) {
//				 card.setUserID(customer.getUserID());
//				 paymentCardsService.save(paymentCardsService.encryptCard(card));
//				 paymentCardsService.decryptCard(card);
//		}

        //Decrypt the password in response
        try {
            customer.setPassword(textEncryptor.decrypt(customer.getPassword()));
        } catch (Exception e) {
            log.error("Exception occured : {}", e.getStackTrace());
        }


        return new ResponseEntity<Customer>(customer, HttpStatus.OK);
    }


    @PostMapping("/forgetPassword")
    public Map<Integer, Customer> forgetPassword(@RequestBody Map<String, String> requestBody) {

        Map<Integer, Customer> result = new HashMap<Integer, Customer>();

        //Send the verification code email
        String email = requestBody.get("email");
        Customer customer = null;
        if (!userService.checkIfCustomerExists(email)) {
            result.put(204, customer);
            return result;
        }

        int code = (int) Math.floor(Math.random() * (max - min + 1) + min);
        String emailBody = "Please use this verification code to activate your account: " + code;
        String emailSubject = "Verify Account";
        try {
            emailSenderService.sendEmail(email, emailBody, emailSubject);

        } catch (Exception e) {
            log.error("Exception occured : {}", e.getStackTrace());
            result.put(502, customer);
            return result;

        }
        customer = userService.findByEmail(email).get(0);
        customer.setVerificationCode(code);
        userService.save(customer);

        try {
            customer.setPassword(textEncryptor.decrypt(customer.getPassword()));
        } catch (Exception e) {
            // TODO Auto-generated catch block
        }
        result.put(200, customer);
        return result;


    }

    @PostMapping("/changePassword")
    public ResponseEntity<Customer> changePassword(@RequestBody Map<String, String> requestBody) {

        //Set the encrypted password and send email
        String email = requestBody.get("email");
        String password = requestBody.get("password");

        List<Customer> customerList = userService.findByEmail(email);

        if (!customerList.isEmpty()) {

            Customer customer = customerList.get(0);
            try {
                customer.setPassword(textEncryptor.encrypt(password));
                ResponseEntity.ok(userService.save(customer));
            } catch (Exception e) {
                log.error("Exception occured while changing pass",e);
            }


            String emailBody = "Your password has been changed";
            String emailSubject = "Profile Updated";
            try {
                emailSenderService.sendEmail(email, emailBody, emailSubject);

            } catch (Exception e) {
                // TODO Auto-generated catch block
                log.error("Exception occured while changing pass",e);
                return new ResponseEntity<Customer>(HttpStatus.BAD_REQUEST);

            }

        }
        return new ResponseEntity<Customer>(HttpStatus.OK);

    }


    @GetMapping("/getAllcustomers")
    public List<Customer> getAllCustomers() {
        List<Customer> list = userService.getAllUsers();
        return list;
    }


    public boolean checkCustomerExists(String email) {

        List<Customer> customerList = userService.findByEmail(email);

        if (customerList.isEmpty()) {
            System.out.println("No customer email found");
            return false;
        }

        return true;

    }

    @PostMapping("/getCustomer")
    public Map<Integer, CustomerBody> getCustomer(@RequestBody Customer customer) {

        Map<Integer, CustomerBody> resultMap = new HashMap<Integer, CustomerBody>();
        //Get the customer by email and password
        String email = customer.getEmail();
        String password = customer.getPassword();
        List<Customer> customerList = userService.findByEmail(email);

        if (!checkCustomerExists(customer.getEmail())) {
            resultMap.put(204, new CustomerBody());
            return resultMap;
        }

        log.info("Pass : {}",textEncryptor.decrypt(customerList.get(0).getPassword()));
        //Check if the password is similar or not
        try {
            if (!textEncryptor.decrypt(customerList.get(0).getPassword()).equals(password)) {
                System.out.println("Incorrect Password");
                resultMap.put(203, new CustomerBody());
                return resultMap;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block

        }

        //Decrypt the password in response
        Customer customerResponse = customerList.get(0);
        try {
            customerResponse.setPassword(textEncryptor.decrypt(customerResponse.getPassword()));
        } catch (Exception e) {
            // TODO Auto-generated catch block

        }

        CustomerBody result = new CustomerBody();
        result.setCustomer(customerResponse);

        // Fetch the cards and attach to the response
        List<PaymentCards> cards = paymentCardsService.getCardsByUserId(customerResponse.getUserID());

        for (PaymentCards card : cards) {
            paymentCardsService.decryptCard(card);
        }

        result.setCardDetails(cards);
        resultMap.put(200, result);

        return resultMap;

    }

    @PostMapping("/getCustomerById")
    public ResponseEntity<CustomerBody> getCustomerById(@RequestBody Customer customer) {
       return customerService.getCustomerById(customer);
    }
    

    @PostMapping("/getCardById")
    public ResponseEntity<PaymentCards> getCardById(@RequestBody PaymentCards card) {
        return customerService.getCardById(card);
    }
}
