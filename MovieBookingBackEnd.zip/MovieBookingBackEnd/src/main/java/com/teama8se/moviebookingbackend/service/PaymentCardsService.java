package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.PaymentCards;
import com.teama8se.moviebookingbackend.repository.PaymentCardsRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 24-03-2024 02:03
 **/

@Service
@Slf4j
public class PaymentCardsService {

    private final PaymentCardsRepository paymentCardsRepository;
    private final TextEncryptor textEncryptor;

    PaymentCardsService(PaymentCardsRepository paymentCardsRepository, TextEncryptor textEncryptor) {
        this.paymentCardsRepository = paymentCardsRepository;
        this.textEncryptor = textEncryptor;
    }

    public List<PaymentCards> findCardById(int cardId){

        return paymentCardsRepository.findByCardID(cardId);
    }

    public List<PaymentCards> getCardsByUserId(int userId){
        return paymentCardsRepository.findByUserID(userId);
    }

    public List<PaymentCards> findByCardNumber(String cardNumber){
        return paymentCardsRepository.findByCardNumber(cardNumber);
    }

    public PaymentCards save(PaymentCards paymentCards){
        return paymentCardsRepository.save(paymentCards);
    }

    public void  deleteCard(PaymentCards paymentCards){
        paymentCardsRepository.delete(paymentCards);
    }

    public PaymentCards encryptCard(PaymentCards card) {

        try {
            card.setCardNumber(textEncryptor.encrypt(card.getCardNumber()));
            card.setExpiryDate(textEncryptor.encrypt(card.getExpiryDate()));
            card.setNameOnCard(textEncryptor.encrypt(card.getNameOnCard()));
            card.setSecurityNumber(textEncryptor.encrypt(card.getSecurityNumber()));
            card.setCardType(textEncryptor.encrypt(card.getCardType()));
            card.setStreet(textEncryptor.encrypt(card.getStreet()));
            card.setCity(textEncryptor.encrypt(card.getCity()));
            card.setState(textEncryptor.encrypt(card.getState()));
            card.setZipcode(textEncryptor.encrypt(card.getZipcode()));


        } catch (Exception e) {

        }
        return card;


    }

    public PaymentCards decryptCard(PaymentCards card) {

        try {
            card.setCardNumber(textEncryptor.decrypt(card.getCardNumber()));
            card.setExpiryDate(textEncryptor.decrypt(card.getExpiryDate()));
            card.setNameOnCard(textEncryptor.decrypt(card.getNameOnCard()));
            card.setSecurityNumber(textEncryptor.decrypt(card.getSecurityNumber()));
            card.setCardType(textEncryptor.decrypt(card.getCardType()));
            card.setStreet(textEncryptor.decrypt(card.getStreet()));
            card.setCity(textEncryptor.decrypt(card.getCity()));
            card.setState(textEncryptor.decrypt(card.getState()));
            card.setZipcode(textEncryptor.decrypt(card.getZipcode()));


        } catch (Exception e) {

        }
        return card;


    }

    public boolean checkCardExists(PaymentCards card) {

        String cardNumber = card.getCardNumber();
        List<PaymentCards> cardList = getCardsByUserId(card.getUserID());

        for (PaymentCards cardDetails : cardList) {
            decryptCard(cardDetails);
            if (cardDetails.getCardNumber().equals(cardNumber)) {
                return true;
            }
        }

        return false;

    }

    public boolean checkCardAvailaibility(PaymentCards card) {

        int userID = card.getUserID();
        List<PaymentCards> cardList = getCardsByUserId(userID);
        return cardList.size() < 3;

    }



}
