package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.awt.print.Book;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

    public List<Booking> findAll();

    public List<Booking> findByBookingId(int bookingId);

    public List<Booking> findByCustomerId(int customerId);

    public List<Booking> findByShowId(int showId);

    public List<Booking> findByCustomerIdAndPromoCode(int customerId, String promocode);
}
