package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.PaymentCards;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentCardsRepository extends JpaRepository<PaymentCards,Integer> {

    List<PaymentCards> findByCardID(int cardID);

    List<PaymentCards> findByUserID(int userID);

    List<PaymentCards> findByCardNumber(String cardNumber);
}
