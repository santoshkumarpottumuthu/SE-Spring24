package com.teama8se.moviebookingbackend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;

/**
 * @author Santosh created on 24-03-2024 02:34
 **/
@Configuration
public class ProjectConfig {
    @Bean
    public TextEncryptor textEncryptor() {
        return Encryptors.text("64696e676f", "73616c7479");
    }
}
