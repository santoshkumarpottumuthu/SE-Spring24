package com.teama8se.moviebookingbackend.enums;

public enum CustomerStatus {
	ACTIVE,
	INACTIVE
}
