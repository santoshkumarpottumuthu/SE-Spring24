package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.designpatterns.facade.AdminFacade;
import com.teama8se.moviebookingbackend.entities.Admin;
import com.teama8se.moviebookingbackend.entities.Movie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * @author Santosh created on 13-04-2024 00:15
 **/

/**
 * We're using Facade Design pattern through this controller,
 * AdminFacade is an Interface which holds all the operations to be performed by the admin.
 *
 */
@RestController
@CrossOrigin("*")
@RequestMapping("/admin")
public class AdminControllerV2 {

    private final AdminFacade adminFacade;

    public AdminControllerV2(AdminFacade adminFacade) {
        this.adminFacade = adminFacade;
    }

    @PostMapping("/addmovie")
    public Map<Integer, Movie> addMovie(@RequestBody Movie movie) {
       return adminFacade.addMovie(movie);
    }
    @PostMapping("/updatemovie")
    public Map<Integer, Movie> editmovie(@RequestBody Movie movie) {
        return adminFacade.updateMovie(movie);
    }

    @PostMapping("/deletemovie")
    public boolean deleteMovie(@RequestBody Movie movie) {
       return adminFacade.deleteMovie(movie);
    }

    @PostMapping("/registerAdmin")
    public ResponseEntity<Admin> register(@RequestBody Admin admin) {
        return adminFacade.addAdmin(admin);
    }


    @PostMapping("/updateAdmin")
    public ResponseEntity<Admin> update(@RequestBody Admin admin) {
       return adminFacade.updateAdmin(admin);
    }

    @PostMapping("/deleteAdmin")
    public boolean deleteAdmin(@RequestBody Admin admin) {
       return adminFacade.deleteAdmin(admin);
    }



}
