package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.designpatterns.facadeImpl.BookingFacadeImpl;
import com.teama8se.moviebookingbackend.entities.Booking;
import com.teama8se.moviebookingbackend.entities.BookingRequest;
import com.teama8se.moviebookingbackend.service.BookingService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 24-03-2024 00:26
 **/
@RestController
@CrossOrigin("*")
public class BookingController {

    private final BookingService bookingService;
    private final BookingFacadeImpl bookingFacade;
    public BookingController(BookingService bookingService, BookingFacadeImpl bookingFacade) {
        this.bookingService = bookingService;
        this.bookingFacade = bookingFacade;
    }

    @PostMapping("/addBooking")
    public BookingRequest addBooking(@RequestBody BookingRequest bookingRequest) {
        return bookingFacade.addBooking(bookingRequest);
    }

    @PostMapping("/getCustomerBookings")
    public List<BookingRequest> getCustomerBookings(@RequestBody Map<String, Integer> request) {
        return bookingFacade.getCustomerBookings(request);
    }

    public List<Booking> getBookingsByCustID(int id) {

        List<Booking> bookings = bookingService.findByCustomerId(id);
        return bookings;

    }

    public Map<Integer, List<Booking>> getBookingsByBookingID(Booking booking) {

        Map<Integer, List<Booking>> result = new HashMap<>();
        List<Booking> bookings = bookingService.findByBookingId(booking.getBookingId());
        result.put(400, bookings);
        return result;

    }

    public Map<Integer, List<Booking>> getBookingsByMovieID(Booking booking) {

        Map<Integer, List<Booking>> result = new HashMap<Integer, List<Booking>>();
        List<Booking> bookings = bookingService.findByShowId(booking.getMovieId());
        result.put(400, bookings);
        return result;

    }

}
