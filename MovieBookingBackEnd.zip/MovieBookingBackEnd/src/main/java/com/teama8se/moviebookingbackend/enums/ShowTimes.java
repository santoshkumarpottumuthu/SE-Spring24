package com.teama8se.moviebookingbackend.enums;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(using = ShowTimesSerializer.class)
@JsonDeserialize(using = ShowTimesDeserializer.class)
public enum ShowTimes {
	MORNING(10),
	NOON(13),
	PRE_EVENING(16),
	EVENING(19),
	NIGHT(22);
	
	public final int time;
	 
	ShowTimes(int time) {
		this.time = time;
	}
	
	public int getTime() { return time; }
}
