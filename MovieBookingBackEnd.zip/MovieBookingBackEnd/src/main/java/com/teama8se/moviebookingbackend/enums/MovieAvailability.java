package com.teama8se.moviebookingbackend.enums;

public enum MovieAvailability {
	
	CURRENTLY_RUNNING,
	COMING_SOON,
	ARCHIVED
	
}
