package com.teama8se.moviebookingbackend.designpatterns.facadeImpl;

import com.teama8se.moviebookingbackend.designpatterns.facade.AdminFacade;
import com.teama8se.moviebookingbackend.entities.Admin;
import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.Movie;
import com.teama8se.moviebookingbackend.entities.Promotion;
import com.teama8se.moviebookingbackend.repository.MovieRepository;
import com.teama8se.moviebookingbackend.service.EmailSenderService;
import com.teama8se.moviebookingbackend.service.PaymentCardsService;
import com.teama8se.moviebookingbackend.service.UserService;
import com.teama8se.moviebookingbackend.service.impl.AdminService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 12-04-2024 23:49
 **/
@Service
public class AdminFacadeImpl implements AdminFacade {

    private final AdminService adminService;
    private final UserService userService;
    private final EmailSenderService emailSenderService;
    private final PaymentCardsService paymentCardsService;

    private final MovieRepository movieRepository;

    public AdminFacadeImpl(AdminService adminService, UserService userService, EmailSenderService emailSenderService, PaymentCardsService paymentCardsService, MovieRepository movieRepository) {
        this.adminService = adminService;
        this.userService = userService;
        this.emailSenderService = emailSenderService;
        this.paymentCardsService = paymentCardsService;
        this.movieRepository = movieRepository;
    }

    @Override
    public Map<Integer, Movie> addMovie(Movie movie) {
        ResponseEntity.ok(movieRepository.save(movie));
        Map<Integer, Movie> map = new HashMap<Integer, Movie>();
        map.put(200, movie);
        return map;
    }

    @Override
    public ResponseEntity<Admin> addAdmin(Admin admin) {

        if (!checkAdminExists(admin)) {
            return new ResponseEntity<Admin>(admin, HttpStatus.BAD_REQUEST);
        }
        ResponseEntity.ok(adminService.registerOrUpdateAdmin(admin));
        return new ResponseEntity<Admin>(admin, HttpStatus.OK);
    }

    @Override
    public void addPromotion(Promotion promo) {

    }

    @Override
    public Map<Integer, Movie> updateMovie(Movie movie) {
        Map<Integer, Movie> map = new HashMap<Integer, Movie>();
        map.put(400, movie);
        return map;
    }

    @Override
    public ResponseEntity<Admin> updateAdmin(Admin admin) {
        if (!checkAdminExists(admin)) {
            return new ResponseEntity<Admin>(admin, HttpStatus.NO_CONTENT);
        }
        ResponseEntity.ok(adminService.registerOrUpdateAdmin(admin));
        return new ResponseEntity<Admin>(admin, HttpStatus.OK);
    }

    @Override
    public void updateCustomer(Customer customer) {

    }

    @Override
    public boolean deleteMovie(Movie movie) {
        movieRepository.delete(movie); //return true only if successfully deleted the movie
        return true;
    }

    @Override
    public boolean deleteAdmin(Admin admin) {
        adminService.deleteAdmin(admin);
        return true;
    }

    @Override
    public void deletePromotion(Promotion promo) {

    }

    @Override
    public void deleteCustomer(Customer customer) {

    }


    public boolean checkAdminExists(Admin admin) {
        String email = admin.getEmail();
        List<Admin> adminList = adminService.findByEmail(email);
        return adminList.isEmpty();
    }
}
