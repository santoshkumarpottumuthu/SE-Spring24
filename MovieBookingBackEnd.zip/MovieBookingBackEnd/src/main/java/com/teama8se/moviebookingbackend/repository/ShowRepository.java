package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Show;
import com.teama8se.moviebookingbackend.entities.ShowReservations;
import com.teama8se.moviebookingbackend.enums.ShowTimes;
import org.springframework.data.jpa.repository.JpaRepository;

import java.sql.Date;
import java.util.List;

public interface ShowRepository extends JpaRepository<Show, Integer> {

    List<Show> findByShowId(int showId);

    List<Show> findByMovieId(int movieId);

    List<Show> findByShowDateAndShowTime(Date showDate, ShowTimes showTime);

    List<Show> findByShowDate(Date showDate);

    List<Show> findByShowDateAndMovieId(Date showDate, int movieId);

}
