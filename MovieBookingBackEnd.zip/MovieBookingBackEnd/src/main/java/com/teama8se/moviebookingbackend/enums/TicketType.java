package com.teama8se.moviebookingbackend.enums;

public enum TicketType {
	
	CHILD,
	ADULT

}
