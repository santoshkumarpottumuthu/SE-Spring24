package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.Movie;
import com.teama8se.moviebookingbackend.repository.MovieRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 27-04-2024 18:18
 **/
@Service
public class MovieService {

    private MovieRepository movieDao;

    public MovieService(MovieRepository movieDao) {
        this.movieDao = movieDao;
    }

    public Map<Integer, Movie> addMovie(@RequestBody Movie movie) {
        ResponseEntity.ok(movieDao.save(movie));
        Map<Integer, Movie> map = new HashMap<Integer, Movie>();
        map.put(200, movie);
        return map;
    }

    public List<Movie> getinfo() {
        List<Movie> list = movieDao.findAll();
        return list;
    }

    public ResponseEntity<Movie> getMovieDetailByTitle(@RequestBody Movie movie) {

        String moviename = movie.getMovieTitle();
        List<Movie> movieList = movieDao.findByMovieTitle(moviename);

        if (movieList.isEmpty()) {
            return new ResponseEntity<Movie>(HttpStatus.NO_CONTENT);
        }

        Movie movieResponse = movieList.get(0);
        return new ResponseEntity<Movie>(movieResponse,
                HttpStatus.OK);

    }

    public Map<Integer, Movie> editmovie(@RequestBody Movie movie) {
        ResponseEntity.ok(movieDao.save(movie));
        Map<Integer, Movie> map = new HashMap<Integer, Movie>();
        map.put(400, movie);
        return map;
    }


    public boolean deleteMovie(@RequestBody Movie movie) {
        movieDao.delete(movie);
        return true;
    }

    public Movie getMovieById(int id) {
        return movieDao.findById(id).get();
    }
}
