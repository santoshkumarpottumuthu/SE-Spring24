package com.teama8se.moviebookingbackend.entities;


import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class BookingRequest  {

	Booking booking;
	Ticket[] tickets;
	Movie movie;
	Show show;
	
	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

	public Booking getBooking() {
		return booking;
	}
	
	public void setBooking(Booking booking) {
		this.booking = booking;
	}
	
	public Ticket[] getTickets() {
		return tickets;
	}
	
	public void setTickets(Ticket[] tickets) {
		this.tickets = tickets;
	}
	
	
	

}
