package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.Promotion;
import com.teama8se.moviebookingbackend.repository.PromotionCodeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 27-04-2024 17:44
 **/
@Service
@Slf4j
public class PromotionService {

    private PromotionCodeRepository promotionCodeRepository;

    public PromotionService(PromotionCodeRepository promotionCodeRepository) {
        this.promotionCodeRepository = promotionCodeRepository;
    }

    public double getDiscountByCode(String code) {

        List<Promotion> promoList = promotionCodeRepository.findByPromoCode(code);
        return promoList.get(0).getDiscountApplied();

    }

}
