package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepository extends JpaRepository<Customer,Integer> {

    List<Customer> findAll();

    //Override the findByField method with different return type
    List<Customer> findByUserID(int userId);

    //Override the findByField method with different return type
    List<Customer> findByEmailAndPassword(String email, String password);

    List<Customer> findByEmail(String email);

    //Get the customers who subscribed for promotions
    List<Customer> findBypromotionsSubscribed(boolean promotionsSubscribed);
}
