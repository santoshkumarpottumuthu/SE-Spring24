package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.Show;
import com.teama8se.moviebookingbackend.repository.ShowRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 27-04-2024 18:15
 **/
@Service
public class ShowService {

    private final ShowRepository showRepository;

    public ShowService(ShowRepository showRepository) {
        this.showRepository = showRepository;
    }

    public Show getShowByShowID(int showID) {
        List<Show> shows = showRepository.findByShowId(showID);
        return shows.get(0);
    }
}
