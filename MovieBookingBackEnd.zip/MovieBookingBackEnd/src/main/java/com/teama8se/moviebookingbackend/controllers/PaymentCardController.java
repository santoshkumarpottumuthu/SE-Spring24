package com.teama8se.moviebookingbackend.controllers;

import com.teama8se.moviebookingbackend.entities.PaymentCards;
import com.teama8se.moviebookingbackend.service.PaymentCardsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Santosh created on 24-03-2024 00:27
 **/

@RestController
@CrossOrigin("*")
public class PaymentCardController {

    private final PaymentCardsService paymentCardsService;

    @Autowired
    PaymentCardController(PaymentCardsService paymentCardsService) {
        this.paymentCardsService = paymentCardsService;
    }

    @PostMapping("/addCard")
    public Map<Integer, PaymentCards> addCard(@RequestBody PaymentCards paymentCard) {

        Map<Integer, PaymentCards> result = new HashMap<Integer, PaymentCards>();
        //Save the card details
        if (!paymentCardsService.checkCardAvailaibility(paymentCard)) {
            result.put(509, paymentCard);
            return result;
        }
        if (!paymentCardsService.checkCardExists(paymentCard)) {
            ResponseEntity.ok(paymentCardsService.save(paymentCardsService.encryptCard(paymentCard)));
            paymentCard = paymentCardsService.decryptCard(paymentCard);
            result.put(200, paymentCard);
        } else {
            result.put(208, paymentCard);
        }
        return result;

    }


    @PostMapping("/updateCard")
    public ResponseEntity<PaymentCards> updateCard(@RequestBody PaymentCards paymentCard) {

        //Save the card details
        if (paymentCardsService.checkCardExists(paymentCard)) {
            ResponseEntity.ok(paymentCardsService.save(paymentCardsService.encryptCard(paymentCard)));
            paymentCardsService.decryptCard(paymentCard);
            return new ResponseEntity<>(paymentCard, HttpStatus.OK);
        }
        return new ResponseEntity<>(paymentCard, HttpStatus.NO_CONTENT);
    }


    @PostMapping("/deleteCard")
    public boolean deleteCard(@RequestBody PaymentCards card) {
        if (!paymentCardsService.checkCardExists(card)) {
            return false;
        }
        paymentCardsService.deleteCard(card);
        return true;
    }
}
