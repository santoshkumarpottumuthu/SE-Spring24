package com.teama8se.moviebookingbackend.designpatterns.decorator;

/**
 * @author Santosh created on 14-04-2024 21:18
 **/
public class AdultTicketDecorator extends BaseTicketDecorator {

    private double adultTicketPrice;

    public AdultTicketDecorator() {
        super();
        this.adultTicketPrice = 15;
    }

    @Override
    public double calculateTicketPrice() {

        return adultTicketPrice;
    }

    public double getTicketPrice() {
        return adultTicketPrice;
    }

}
