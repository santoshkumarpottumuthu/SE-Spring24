package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.Booking;
import com.teama8se.moviebookingbackend.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 12-04-2024 23:31
 **/

@Service
public class BookingService {

    private final BookingRepository bookingRepository;

    public BookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }


    public Object addBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    public List<Booking> findByCustomerId(int id) {
        return bookingRepository.findByCustomerId(id);
    }

    public List<Booking> findByBookingId(int bookingId) {

        return bookingRepository.findByBookingId(bookingId);
    }

    public List<Booking> findByShowId(int movieId) {
        return bookingRepository.findByShowId(movieId);
    }
}
