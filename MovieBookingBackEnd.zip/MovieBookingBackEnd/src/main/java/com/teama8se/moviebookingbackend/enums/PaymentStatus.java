package com.teama8se.moviebookingbackend.enums;

public enum PaymentStatus {
	
	SUCCESS,
	PENDING,
	DECLINED
	
}
