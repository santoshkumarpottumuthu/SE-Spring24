package com.teama8se.moviebookingbackend.service;

import com.teama8se.moviebookingbackend.entities.Ticket;
import com.teama8se.moviebookingbackend.repository.TicketRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Santosh created on 12-04-2024 23:06
 **/

@Service
public class TicketService {


    private final TicketRepository ticketRepository;

    public TicketService(TicketRepository ticketRepository) {
        this.ticketRepository = ticketRepository;
    }


    public Map<Integer, Ticket> addTicket(Ticket ticket) {

        Map<Integer, Ticket> result  = new HashMap<Integer, Ticket>();
        ResponseEntity.ok(ticketRepository.save(ticket));
        result.put(400, ticket);
        return result;

    }

    public List<Ticket> getTickets(int bookingID) {
        return ticketRepository.findByBookingId(bookingID);
    }

    public Ticket save(Ticket ticket) {
        return ticketRepository.save(ticket);
    }

    public List<Ticket> findByBookingId(int bookingID) {
        return ticketRepository.findByBookingId(bookingID);
    }
}
