package com.teama8se.moviebookingbackend.entities;

import java.sql.Date;


import com.teama8se.moviebookingbackend.enums.BookingStatus;
import com.teama8se.moviebookingbackend.enums.PaymentStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="booking")
public class Booking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookingId;
	private int customerId;
	private int paymentId;
	private int movieId;
	private String promoCode;
	private int showId;
	private double totalPrice;
	private Date bookingDate;
	@Enumerated(EnumType.ORDINAL)
	private BookingStatus bookingStatus;
	@Enumerated(EnumType.ORDINAL)
	private PaymentStatus paymentStatus;
	

	public Booking() {
		super();
	}
	
	
	public Booking(int bookingId, int customerId, int paymentId, int movieId, String promoCode, int showId, double totalPrice, BookingStatus bookingStatus,
			PaymentStatus paymentStatus, Date bookingDate) {
		super();
		this.bookingId = bookingId;
		this.customerId = customerId;
		this.paymentId = paymentId;
		this.movieId = movieId;
		this.totalPrice = totalPrice;
		this.bookingStatus = bookingStatus;
		this.paymentStatus = paymentStatus;
		this.promoCode = promoCode;
		this.showId = showId;
		this.bookingDate = bookingDate;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public PaymentStatus getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(PaymentStatus paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}
	public int getShowId() {
		return showId;
	}
	public void setShowId(int showId) {
		this.showId = showId;
	}


	public Date getBookingDate() {
		return bookingDate;
	}


	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	
	
	
	
}
