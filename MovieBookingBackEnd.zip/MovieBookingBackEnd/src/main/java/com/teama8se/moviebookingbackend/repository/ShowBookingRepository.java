package com.teama8se.moviebookingbackend.repository;

import com.teama8se.moviebookingbackend.entities.ShowReservations;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ShowBookingRepository extends JpaRepository<ShowReservations, Integer> {

    List<ShowReservations> findByShowID(int showID);

}
