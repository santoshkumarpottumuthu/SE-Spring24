package com.teama8se.moviebookingbackend.service.impl;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.teama8se.moviebookingbackend.entities.Address;
import com.teama8se.moviebookingbackend.entities.Customer;
import com.teama8se.moviebookingbackend.entities.UserEntity;
import com.teama8se.moviebookingbackend.enums.CustomerStatus;
import com.teama8se.moviebookingbackend.enums.UserRole;
import com.teama8se.moviebookingbackend.repository.AddressRepository;
import com.teama8se.moviebookingbackend.repository.UserRepository;
import com.teama8se.moviebookingbackend.service.UserService;
import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Santosh created on 24-03-2024 00:46
 **/
@Service
public class CustomerServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final AddressRepository addressRepository;

    CustomerServiceImpl(UserRepository userRepository, AddressRepository addressRepository) {
        this.userRepository = userRepository;
        this.addressRepository = addressRepository;
    }

    @Override
    public List<Customer> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public List<Customer> fetchUserByUserID(int userID) {
        return userRepository.findByUserID(userID);
    }

    @Override
    public List<Customer> findByEmailAndPassword(String email, String password) {
        return null;
    }

    @Override
    public List<Customer> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public List<Customer> findBypromotionsSubscribed(boolean promotionsSubscribed) {
        return userRepository.findBypromotionsSubscribed(promotionsSubscribed);
    }

    @Override
    public boolean checkIfCustomerExists(String email) {

        List<Customer> customerList = userRepository.findByEmail(email);

        if (customerList.isEmpty()) {
            System.out.println("No customer email found");
            return false;
        }

        return true;

    }

//    @Override
//    public Customer save(Customer customer) {
//        UserEntity user = new UserEntity();
//        user.setEmail(customer.getEmail());
//        user.setPassword(customer.getPassword());
////        user.setUserID(customer.getUserID());
//        user.setUserRole(customer.getUserRole());
//        user.setFirstName(customer.getFirstName());
//        user.setLastName(customer.getLastName());
//        user.setCustomerStatusID(customer.getCustomerStatusID());
//        user.setPhoneNumber(customer.getPhoneNumber());
//        user.setPromotionsSubscribed(customer.isPromotionsSubscribed());
//        user.setVerificationCode(customer.getVerificationCode());
//
//        Address savedAddress;
//        if(customer.getCity()!=null && !Strings.isBlank(customer.getCity())){
//            Address address = new Address(customer.getStreet(),customer.getCity(),customer.getState(), customer.getZipcode());
//            savedAddress = addressRepository.save(address);
//            user.setAddress(address);
//        }
//
//
//        return userRepository.save(customer);
//    }
    @Override
    public Customer save(Customer customer){
        return userRepository.save(customer);
    }
    @Override
    public void delete(Customer customer) {
         userRepository.delete(customer);
    }

}

