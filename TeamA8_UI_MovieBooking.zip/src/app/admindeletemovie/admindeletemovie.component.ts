import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admindeletemovie',
  templateUrl: './admindeletemovie.component.html',
  styleUrls: ['./admindeletemovie.component.css']
})
export class AdmindeletemovieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
